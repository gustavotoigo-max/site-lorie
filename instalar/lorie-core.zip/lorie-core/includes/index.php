<?php
// Silêncio é ouro.
